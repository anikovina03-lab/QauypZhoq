# QauypZhoq AI

## Render deployment

This version serves the existing website and adds:
- AI cybersecurity chat (Kazakh/Russian/English)
- AI analysis for suspicious messages
- AI analysis of URL text (the URL is not opened or live-scanned)

### Deploy as a Node Web Service
1. Upload these files to the root of your GitHub repository, replacing the old `index.html`.
2. In Render, create a **Web Service** connected to that repository (or change the existing service to a Node Web Service if the dashboard offers that option).
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Add Environment Variable:
   - Key: `OPENAI_API_KEY`
   - Value: paste your secret API key directly into Render's value field.
6. Optional Environment Variable:
   - Key: `OPENAI_MODEL`
   - Value: `gpt-6.2-sol`
7. Deploy. Open `/health` on the deployed site; it should return `{"ok":true}`.

Do not put the OpenAI key in `index.html`, GitHub, screenshots, or chat messages.
If the key was ever exposed publicly, revoke it and create a new one.

### Notes
- Existing browser-side site functionality and local login UI are preserved as found in the supplied HTML.
- The existing login implementation is browser-local, not server-side account authentication.
- AI analysis sends the text entered by the visitor to the server and OpenAI for processing. Do not submit passwords, SMS codes, CVV, or full card numbers.
- AI URL analysis inspects the URL string only; it does not visit the site or guarantee safety.
- API usage may incur separate charges under your OpenAI API billing account.
